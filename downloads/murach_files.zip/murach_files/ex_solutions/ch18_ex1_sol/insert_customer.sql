INSERT INTO customers
    (firstName, lastName, emailAddress, password) 
VALUES 
    ('John', 'Smith', 'johnsmith@example.com', 'sesame')