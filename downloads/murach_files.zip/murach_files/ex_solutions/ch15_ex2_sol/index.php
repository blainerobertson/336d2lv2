<?php include 'view/header.php'; ?>
<main>
    <h1>Menu</h1>
    <p><a href="product_manager">Product Manager</a></p>
    <p><a href="product_catalog">Product Catalog</a></p>
</main>
<?php include 'view/footer.php'; ?>