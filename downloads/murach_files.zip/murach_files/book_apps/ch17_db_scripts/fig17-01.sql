DROP DATABASE IF EXISTS my_guitar_shop2;

CREATE DATABASE my_guitar_shop2;

USE my_guitar_shop2;