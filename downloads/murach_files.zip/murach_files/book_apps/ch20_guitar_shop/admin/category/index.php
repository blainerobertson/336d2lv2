<?php  include '../../util/main.php'; ?>
<?php include '../../view/header.php'; ?>
<section>
    <h2>Category Manager - under construction</h2>
</section>
<?php include '../../view/footer.php'; ?>
